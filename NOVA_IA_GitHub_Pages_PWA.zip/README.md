# NOVA IA - GitHub Pages PWA

## Publicación
1. Crea un repositorio público llamado `nova-ia`.
2. Sube TODO el contenido de esta carpeta a la raíz del repositorio (index.html debe quedar en la raíz).
3. En GitHub: Settings > Pages > Build and deployment > Deploy from a branch.
4. Selecciona `main` y `/ (root)`, luego Save.
5. Espera a que GitHub Pages publique el sitio.

## Instalación
- iPhone: abrir la URL publicada en Safari > Compartir > Añadir a pantalla de inicio.
- Android: abrir la URL en Chrome > menú > Instalar aplicación o Añadir a pantalla de inicio.

## Límites
Esta versión es una interfaz PWA estática. No incluye un modelo de IA ni backend. No coloques claves, contraseñas ni tokens en los archivos públicos. GitHub Pages no ejecuta FastAPI ni Python.

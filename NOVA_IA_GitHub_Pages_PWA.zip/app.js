const form=document.getElementById('chatForm');
const input=document.getElementById('messageInput');
const messages=document.getElementById('messages');
const welcome=document.getElementById('welcome');
const note=document.getElementById('connectionNote');
const history=document.getElementById('history');
const sidebar=document.getElementById('sidebar');
let chatItems=[];
function addBubble(text,kind){const el=document.createElement('div');el.className='bubble '+kind;el.textContent=text;messages.appendChild(el);el.scrollIntoView({behavior:'smooth',block:'nearest'});}
function renderHistory(){history.replaceChildren();if(!chatItems.length){const p=document.createElement('p');p.className='empty';p.textContent='Tus conversaciones aparecerán aquí.';history.appendChild(p);return;}chatItems.forEach((item,i)=>{const b=document.createElement('button');b.className='suggestion';b.style.cssText='display:block;width:100%;text-align:left;margin:6px 0;color:#dce6fa';b.textContent=item.slice(0,30);b.onclick=()=>{messages.replaceChildren();addBubble(item,'user');};history.appendChild(b);});}
function send(text){const value=(text||'').trim();if(!value)return;welcome.hidden=true;addBubble(value,'user');chatItems.unshift(value);renderHistory();input.value='';note.textContent='Mensaje guardado en esta vista. El backend todavía no está conectado; NOVA no generará una respuesta ficticia.';addBubble('La conexión con el modelo de NOVA IA todavía no está disponible. Cuando conectemos el backend, podré responderte aquí.','notice');}
form.addEventListener('submit',e=>{e.preventDefault();send(input.value);});
document.querySelectorAll('[data-prompt]').forEach(b=>b.addEventListener('click',()=>{input.value=b.dataset.prompt;input.focus();}));
document.getElementById('newChat').addEventListener('click',()=>{messages.replaceChildren();welcome.hidden=false;note.textContent='Interfaz preparada. El modelo de IA aún no está conectado.';sidebar.classList.remove('open');});
document.getElementById('menuToggle').addEventListener('click',()=>sidebar.classList.toggle('open'));
